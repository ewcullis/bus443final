from django.shortcuts import render
from django.http import HttpResponse
from studentinfo.models import student, course, studentenrollment
from django.db import connection
from django.core.paginator import Paginator
from django.contrib.auth.decorators import login_required

# Create your views here.

@login_required
def home(request):
    studentdata = student.objects.all()
    coursedata = course.objects.all()
    freshmancount = student.objects.filter(year='Freshman').count()
    sophomorecount = student.objects.filter(year='Sophomore').count()
    juniorcount = student.objects.filter(year='Junior').count()
    seniorcount = student.objects.filter(year='Senior').count()
    freshmangpa = 0
    sophomoregpa = 0
    juniorgpa = 0
    seniorgpa = 0
    for i in student.objects.filter(year='Freshman'):
        freshmangpa += i.gpa
    if freshmancount > 0:
        freshmangpa /= student.objects.filter(year='Freshman').count()
        freshmangpa = round(freshmangpa,2)
    for i in student.objects.filter(year='Sophomore'):
        sophomoregpa += i.gpa
    if sophomorecount > 0:
        sophomoregpa /= student.objects.filter(year='Sophomore').count()
        sophomoregpa = round(sophomoregpa,2)
    for i in student.objects.filter(year='Junior'):
        juniorgpa += i.gpa
    if juniorcount > 0:
        juniorgpa /= student.objects.filter(year='Junior').count()
        juniorgpa = round(juniorgpa,2)
    for i in student.objects.filter(year='Senior'):
        seniorgpa += i.gpa
    if seniorcount > 0:
        seniorgpa /= student.objects.filter(year='Senior').count()
        seniorgpa = round(seniorgpa,2)
    f = ['Freshman', freshmancount, freshmangpa]
    so = ['Sophomore', sophomorecount, sophomoregpa]
    j = ['Junior', juniorcount, juniorgpa]
    s = ['Senior', seniorcount, seniorgpa]
    list = [f, so, j, s]
    studentcount = [student.objects.all().count()]
    coursecount = [course.objects.all().count()]
    second = [studentcount, coursecount]
    context = {'data':list, 'second':second}
    return render(request, 'studentinfo/home.html', context)

@login_required
def students(request):
    studentdata = student.objects.all()
    paginator = Paginator(studentdata, 10)
    page = request.GET.get('page')
    minidata = paginator.get_page(page)
    context = {'data':minidata}
    return render(request, 'studentinfo/students.html', context)

#def dictfetchall(cursor):
#    columns = [col[0] for col in cursor.description]
#    return [
#        dict(zip(columns, row))
#        for row in cursor.fetchall()
#    ]

#def students(request):
#    cursorobj = connection.cursor()
#    cursorobj.execute("select * from stuentinfo_studentdetails")
#    studentdata = dictfetchall(cursorobj)
#    print(studentdata)
#    context = {'data':studentdata}
#    return render(request, 'studentinfo/students.html', context)

@login_required
def enrollment(request):
    studentdata = student.objects.all()
    coursedata = course.objects.all()
    studentenrollmentdata = studentenrollment.objects.all()
    context = {'student':studentdata, 'course':coursedata, 'studentenrollment':studentenrollmentdata}
    return render(request, 'studentinfo/enrollment.html', context)

def saveenrollment(request):
    if('sname' and 'cname' in request.GET):
        stuname = request.GET.get('sname')
        couname = request.GET.get('cname')
        if (studentenrollment.objects.filter(enrolledstudent = stuname)).count() > 2:
            return HttpResponse("Student is already enrolled in three courses.")
        for enrolled in studentenrollment.objects.all():
            if enrolled.enrolledstudent == stuname:
                if enrolled.enrolledcourse == couname:
                    return HttpResponse("Student is already enrolled in this course.")
        dataobj = studentenrollment(enrolledstudent = stuname, enrolledcourse = couname)
        dataobj.save()
        return HttpResponse("Success")

def selectedstudent(request):
    stu = request.GET.get('stu')
    cou = studentenrollment.objects.filter(enrolledstudent = stu)
    context = {'courses':cou}
    return render(request, 'studentinfo/selectedstudent.html', context)

@login_required
def courses(request):
    coursedata = course.objects.all()
    count = course.objects.all().count()
    if count < 2:
        paginator = Paginator(coursedata, 1)
    elif count % 2 == 1:
        paginator = Paginator(coursedata, (count/2)+1)
    else:
        paginator = Paginator(coursedata, count/2)
    page = request.GET.get('page')
    minidata = paginator.get_page(page)
    context = {'data':minidata}
    return render(request, 'studentinfo/courses.html', context)
