from django.db import models

# Create your models here.
class student(models.Model):
    studentid = models.IntegerField(primary_key=True)
    firstname = models.CharField(max_length=200)
    lastname = models.CharField(max_length=200)
    major = models.CharField(max_length=200)
    year = models.CharField(max_length=200)
    gpa = models.FloatField()

class course(models.Model):
    courseid = models.IntegerField(primary_key=True)
    title = models.CharField(max_length=200)
    name = models.CharField(max_length=200)
    section = models.IntegerField()
    department = models.CharField(max_length=200)
    instructor = models.CharField(max_length=200)

class studentenrollment(models.Model):
    enrolledstudent = models.CharField(max_length=200)
    enrolledcourse = models.CharField(max_length=200)
