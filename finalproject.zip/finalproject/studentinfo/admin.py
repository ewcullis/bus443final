from django.contrib import admin
from studentinfo.models import student, course, studentenrollment

# Register your models here.

admin.site.register(student)
admin.site.register(course)
admin.site.register(studentenrollment)
